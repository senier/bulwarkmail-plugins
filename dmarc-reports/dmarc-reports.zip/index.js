var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// dmarc-reports/src/index.js
var index_exports = {};
__export(index_exports, {
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);
var React = __toESM(require("react"), 1);
var import_plugin_host = __toESM(require("@plugin-host"), 1);

// dmarc-reports/src/lib/detect.js
var SUBJECT = /report domain:|dmarc[^\n]{0,24}report|aggregate report/i;
var NAME = /!\d{9,11}!\d{9,11}(![^.]*)?\.(xml|xml\.gz|gz|zip)$/i;
var FILE = /\.(xml|xml\.gz|gz|zip)$/i;
var TYPE = /^(application\/(gzip|x-gzip|zip|x-zip-compressed|xml|octet-stream)|text\/xml)$/i;
var MAX_REPORTS = 3;
function reportAttachments(email) {
  const subjectHit = SUBJECT.test(String(email?.subject ?? ""));
  const list = Array.isArray(email?.attachments) ? email.attachments : [];
  return list.filter((a) => a && a.blobId && Number(a.size) > 0).filter((a) => NAME.test(a.name ?? "") || subjectHit && (FILE.test(a.name ?? "") || TYPE.test(a.type ?? ""))).slice(0, MAX_REPORTS);
}
function shouldShow(props) {
  const email = props?.email;
  if (!email) return false;
  return SUBJECT.test(String(email.subject ?? "")) || reportAttachments(email).length > 0;
}

// dmarc-reports/src/ui/banner.js
var import_ui2 = require("@plugin-host/ui");

// dmarc-reports/node_modules/fflate/esm/browser.js
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start) {
  var b = new u16(31);
  for (var i2 = 0; i2 < 31; ++i2) {
    b[i2] = start += 1 << eb[i2 - 1];
  }
  var r = new i32(b[30]);
  for (var i2 = 1; i2 < 30; ++i2) {
    for (var j = b[i2]; j < b[i2 + 1]; ++j) {
      r[j] = j - b[i2] << 5 | i2;
    }
  }
  return { b, r };
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (i = 0; i < 32768; ++i) {
  x = (i & 43690) >> 1 | (i & 21845) << 1;
  x = (x & 52428) >> 2 | (x & 13107) << 2;
  x = (x & 61680) >> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var x;
var i;
var hMap = (function(cd, mb, r) {
  var s = cd.length;
  var i2 = 0;
  var l = new u16(mb);
  for (; i2 < s; ++i2) {
    if (cd[i2])
      ++l[cd[i2] - 1];
  }
  var le = new u16(mb);
  for (i2 = 1; i2 < mb; ++i2) {
    le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        var sv = i2 << 4 | cd[i2];
        var r_1 = mb - cd[i2];
        var v = le[cd[i2] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        co[i2] = rev[le[cd[i2] - 1]++] >> 15 - cd[i2];
      }
    }
  }
  return co;
});
var flt = new u8(288);
for (i = 0; i < 144; ++i)
  flt[i] = 8;
var i;
for (i = 144; i < 256; ++i)
  flt[i] = 9;
var i;
for (i = 256; i < 280; ++i)
  flt[i] = 7;
var i;
for (i = 280; i < 288; ++i)
  flt[i] = 8;
var i;
var fdt = new u8(32);
for (i = 0; i < 32; ++i)
  fdt[i] = 5;
var i;
var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
  var m = a[0];
  for (var i2 = 1; i2 < a.length; ++i2) {
    if (a[i2] > m)
      m = a[i2];
  }
  return m;
};
var bits = function(d, p, m) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  return new u8(v.subarray(s, e));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var inflt = function(dat, st, buf, dict) {
  var sl = dat.length, dl = dict ? dict.length : 0;
  if (!sl || st.f && !st.l)
    return buf || new u8(0);
  var noBuf = !buf;
  var resize = noBuf || st.i != 2;
  var noSt = st.i;
  if (noBuf)
    buf = new u8(sl * 3);
  var cbuf = function(l2) {
    var bl = buf.length;
    if (l2 > bl) {
      var nbuf = new u8(Math.max(bl * 2, l2));
      nbuf.set(buf);
      buf = nbuf;
    }
  };
  var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
  var tbts = sl * 8;
  do {
    if (!lm) {
      final = bits(dat, pos, 1);
      var type = bits(dat, pos + 1, 3);
      pos += 3;
      if (!type) {
        var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
        if (t > sl) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + l);
        buf.set(dat.subarray(s, t), bt);
        st.b = bt += l, st.p = pos = t * 8, st.f = final;
        continue;
      } else if (type == 1)
        lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
      else if (type == 2) {
        var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
        var tl = hLit + bits(dat, pos + 5, 31) + 1;
        pos += 14;
        var ldt = new u8(tl);
        var clt = new u8(19);
        for (var i2 = 0; i2 < hcLen; ++i2) {
          clt[clim[i2]] = bits(dat, pos + i2 * 3, 7);
        }
        pos += hcLen * 3;
        var clb = max(clt), clbmsk = (1 << clb) - 1;
        var clm = hMap(clt, clb, 1);
        for (var i2 = 0; i2 < tl; ) {
          var r = clm[bits(dat, pos, clbmsk)];
          pos += r & 15;
          var s = r >> 4;
          if (s < 16) {
            ldt[i2++] = s;
          } else {
            var c = 0, n = 0;
            if (s == 16)
              n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i2 - 1];
            else if (s == 17)
              n = 3 + bits(dat, pos, 7), pos += 3;
            else if (s == 18)
              n = 11 + bits(dat, pos, 127), pos += 7;
            while (n--)
              ldt[i2++] = c;
          }
        }
        var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
        lbt = max(lt);
        dbt = max(dt);
        lm = hMap(lt, lbt, 1);
        dm = hMap(dt, dbt, 1);
      } else
        err(1);
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
    }
    if (resize)
      cbuf(bt + 131072);
    var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
    var lpos = pos;
    for (; ; lpos = pos) {
      var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
      pos += c & 15;
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
      if (!c)
        err(2);
      if (sym < 256)
        buf[bt++] = sym;
      else if (sym == 256) {
        lpos = pos, lm = null;
        break;
      } else {
        var add = sym - 254;
        if (sym > 264) {
          var i2 = sym - 257, b = fleb[i2];
          add = bits(dat, pos, (1 << b) - 1) + fl[i2];
          pos += b;
        }
        var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
        if (!d)
          err(3);
        pos += d & 15;
        var dt = fd[dsym];
        if (dsym > 3) {
          var b = fdeb[dsym];
          dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
        }
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + 131072);
        var end = bt + add;
        if (bt < dt) {
          var shift = dl - dt, dend = Math.min(dt, end);
          if (shift + bt < 0)
            err(3);
          for (; bt < dend; ++bt)
            buf[bt] = dict[shift + bt];
        }
        for (; bt < end; ++bt)
          buf[bt] = buf[bt - dt];
      }
    }
    st.l = lm, st.p = lpos, st.b = bt, st.f = final;
    if (lm)
      final = 1, st.m = lbt, st.d = dm, st.n = dbt;
  } while (!final);
  return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var et = /* @__PURE__ */ new u8(0);
var b2 = function(d, b) {
  return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
  return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
  return b4(d, b) + b4(d, b + 4) * 4294967296;
};
var gzs = function(d) {
  if (d[0] != 31 || d[1] != 139 || d[2] != 8)
    err(6, "invalid gzip data");
  var flg = d[3];
  var st = 10;
  if (flg & 4)
    st += (d[10] | d[11] << 8) + 2;
  for (var zs = (flg >> 3 & 1) + (flg >> 4 & 1); zs > 0; zs -= !d[st++])
    ;
  return st + (flg & 2);
};
var Inflate = /* @__PURE__ */ (function() {
  function Inflate2(opts, cb) {
    if (typeof opts == "function")
      cb = opts, opts = {};
    this.ondata = cb;
    var dict = opts && opts.dictionary && opts.dictionary.subarray(-32768);
    this.s = { i: 0, b: dict ? dict.length : 0 };
    this.o = new u8(32768);
    this.p = new u8(0);
    if (dict)
      this.o.set(dict);
  }
  Inflate2.prototype.e = function(c) {
    if (!this.ondata)
      err(5);
    if (this.d)
      err(4);
    if (!this.p.length)
      this.p = c;
    else if (c.length) {
      var n = new u8(this.p.length + c.length);
      n.set(this.p), n.set(c, this.p.length), this.p = n;
    }
  };
  Inflate2.prototype.c = function(final) {
    this.s.i = +(this.d = final || false);
    var bts = this.s.b;
    var dt = inflt(this.p, this.s, this.o);
    this.ondata(slc(dt, bts, this.s.b), this.d);
    this.o = slc(dt, this.s.b - 32768), this.s.b = this.o.length;
    this.p = slc(this.p, this.s.p / 8 | 0), this.s.p &= 7;
  };
  Inflate2.prototype.push = function(chunk, final) {
    this.e(chunk), this.c(final);
  };
  return Inflate2;
})();
var Gunzip = /* @__PURE__ */ (function() {
  function Gunzip2(opts, cb) {
    this.v = 1;
    this.r = 0;
    Inflate.call(this, opts, cb);
  }
  Gunzip2.prototype.push = function(chunk, final) {
    Inflate.prototype.e.call(this, chunk);
    this.r += chunk.length;
    if (this.v) {
      var p = this.p.subarray(this.v - 1);
      var s = p.length > 3 ? gzs(p) : 4;
      if (s > p.length) {
        if (!final)
          return;
      } else if (this.v > 1 && this.onmember) {
        this.onmember(this.r - p.length);
      }
      this.p = p.subarray(s), this.v = 0;
    }
    Inflate.prototype.c.call(this, 0);
    if (this.s.f && !this.s.l) {
      this.v = shft(this.s.p) + 9;
      this.s = { i: 0 };
      this.o = new u8(0);
      this.push(new u8(0), final);
    } else if (final) {
      Inflate.prototype.c.call(this, final);
    }
  };
  return Gunzip2;
})();
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}
var dutf8 = function(d) {
  for (var r = "", i2 = 0; ; ) {
    var c = d[i2++];
    var eb = (c > 127) + (c > 223) + (c > 239);
    if (i2 + eb > d.length)
      return { s: r, r: slc(d, i2 - 1) };
    if (!eb)
      r += String.fromCharCode(c);
    else if (eb == 3) {
      c = ((c & 15) << 18 | (d[i2++] & 63) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
    } else if (eb & 1)
      r += String.fromCharCode((c & 31) << 6 | d[i2++] & 63);
    else
      r += String.fromCharCode((c & 15) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63);
  }
};
function strFromU8(dat, latin1) {
  if (latin1) {
    var r = "";
    for (var i2 = 0; i2 < dat.length; i2 += 16384)
      r += String.fromCharCode.apply(null, dat.subarray(i2, i2 + 16384));
    return r;
  } else if (td) {
    return td.decode(dat);
  } else {
    var _a2 = dutf8(dat), s = _a2.s, r = _a2.r;
    if (r.length)
      err(8);
    return s;
  }
}
var z64hs = function(d, b, l, z, sc, su, off) {
  var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
  var nf = nsc + nsu + noff;
  if (z && nf) {
    for (; b + 4 < e; b += 4 + b2(d, b + 2)) {
      if (b2(d, b) == 1) {
        return [
          nsc ? b8(d, b + 4 + 8 * nsu) : sc,
          nsu ? b8(d, b + 4) : su,
          noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
          1
        ];
      }
    }
    if (z < 2)
      err(13);
  }
  return [sc, su, off, 0];
};
var UnzipPassThrough = /* @__PURE__ */ (function() {
  function UnzipPassThrough2() {
  }
  UnzipPassThrough2.prototype.push = function(chunk, final) {
    this.ondata(null, chunk, final);
  };
  UnzipPassThrough2.compression = 0;
  return UnzipPassThrough2;
})();
var UnzipInflate = /* @__PURE__ */ (function() {
  function UnzipInflate2() {
    var _this = this;
    this.i = new Inflate(function(dat, final) {
      _this.ondata(null, dat, final);
    });
  }
  UnzipInflate2.prototype.push = function(chunk, final) {
    try {
      this.i.push(chunk, final);
    } catch (e) {
      this.ondata(e, null, final);
    }
  };
  UnzipInflate2.compression = 8;
  return UnzipInflate2;
})();
var Unzip = /* @__PURE__ */ (function() {
  function Unzip2(cb) {
    this.onfile = cb;
    this.k = [];
    this.o = {
      0: UnzipPassThrough
    };
    this.p = et;
  }
  Unzip2.prototype.push = function(chunk, final) {
    var _this = this;
    if (!this.onfile)
      err(5);
    if (!this.p)
      err(4);
    if (this.c > 0) {
      var len = Math.min(this.c, chunk.length);
      var toAdd = chunk.subarray(0, len);
      this.c -= len;
      if (this.d)
        this.d.push(toAdd, !this.c);
      else
        this.k[0].push(toAdd);
      chunk = chunk.subarray(len);
      if (chunk.length)
        return this.push(chunk, final);
    } else {
      var f = 0, i2 = 0, is = void 0, buf = void 0;
      if (!this.p.length)
        buf = chunk;
      else if (!chunk.length)
        buf = this.p;
      else {
        buf = new u8(this.p.length + chunk.length);
        buf.set(this.p), buf.set(chunk, this.p.length);
      }
      var l = buf.length, oc = this.c, add = oc && this.d;
      var _loop_2 = function() {
        var sig = b4(buf, i2);
        if (sig == 67324752) {
          f = 1, is = i2;
          this_1.d = null;
          this_1.c = 0;
          var bf = b2(buf, i2 + 6), cmp_1 = b2(buf, i2 + 8), u = bf & 2048, dd = bf & 8, fnl = b2(buf, i2 + 26), es = b2(buf, i2 + 28);
          if (l > i2 + 30 + fnl + es) {
            var chks_3 = [];
            this_1.k.unshift(chks_3);
            f = 2;
            var lsc = b4(buf, i2 + 18), lsu = b4(buf, i2 + 22);
            var fn_1 = strFromU8(buf.subarray(i2 + 30, i2 += 30 + fnl), !u);
            var _a2 = z64hs(buf, i2, es, 2, lsc, lsu, 0), sc_1 = _a2[0], su_1 = _a2[1], z64 = _a2[3];
            if (dd)
              sc_1 = -1 - z64;
            i2 += es;
            this_1.c = sc_1;
            var d_1;
            var file_1 = {
              name: fn_1,
              compression: cmp_1,
              start: function() {
                if (!file_1.ondata)
                  err(5);
                if (!sc_1)
                  file_1.ondata(null, et, true);
                else {
                  var ctr = _this.o[cmp_1];
                  if (!ctr)
                    file_1.ondata(err(14, "unknown compression type " + cmp_1, 1), null, false);
                  d_1 = sc_1 < 0 ? new ctr(fn_1) : new ctr(fn_1, sc_1, su_1);
                  d_1.ondata = function(err2, dat3, final2) {
                    file_1.ondata(err2, dat3, final2);
                  };
                  for (var _i = 0, chks_4 = chks_3; _i < chks_4.length; _i++) {
                    var dat2 = chks_4[_i];
                    d_1.push(dat2, false);
                  }
                  if (_this.k[0] == chks_3 && _this.c)
                    _this.d = d_1;
                  else
                    d_1.push(et, true);
                }
              },
              terminate: function() {
                if (d_1 && d_1.terminate)
                  d_1.terminate();
              }
            };
            if (sc_1 >= 0)
              file_1.size = sc_1, file_1.originalSize = su_1;
            this_1.onfile(file_1);
          }
          return "break";
        } else if (oc) {
          if (sig == 134695760) {
            is = i2 += 12 + (oc == -2 && 8), f = 3, this_1.c = 0;
            return "break";
          } else if (sig == 33639248) {
            is = i2 -= 4, f = 3, this_1.c = 0;
            return "break";
          }
        }
      };
      var this_1 = this;
      for (; i2 < l - 4; ++i2) {
        var state_1 = _loop_2();
        if (state_1 === "break")
          break;
      }
      this.p = et;
      if (oc < 0) {
        var dat = f ? buf.subarray(0, is - 12 - (oc == -2 && 8) - (b4(buf, is - 16) == 134695760 && 4)) : buf.subarray(0, i2);
        if (add)
          add.push(dat, !!f);
        else
          this.k[+(f == 2)].push(dat);
      }
      if (f & 2)
        return this.push(buf.subarray(i2), final);
      this.p = buf.subarray(i2);
    }
    if (final) {
      if (this.c)
        err(13);
      this.p = null;
    }
  };
  Unzip2.prototype.register = function(decoder) {
    this.o[decoder.compression] = decoder;
  };
  return Unzip2;
})();

// dmarc-reports/src/lib/unpack.js
var MAX_XML_BYTES = 20 * 1024 * 1024;
var UnpackError = class extends Error {
  constructor(code) {
    super(code);
    this.name = "UnpackError";
    this.code = code;
  }
};
function sniff(bytes) {
  if (bytes.length > 2 && bytes[0] === 31 && bytes[1] === 139) return "gzip";
  if (bytes.length > 3 && bytes[0] === 80 && bytes[1] === 75 && bytes[2] === 3 && bytes[3] === 4) return "zip";
  let i2 = 0;
  if (bytes[0] === 239 && bytes[1] === 187 && bytes[2] === 191) i2 = 3;
  while (i2 < bytes.length && (bytes[i2] === 32 || bytes[i2] === 9 || bytes[i2] === 10 || bytes[i2] === 13)) i2++;
  if (bytes[i2] === 60) return "xml";
  if (bytes[0] === 255 && bytes[1] === 254 || bytes[0] === 254 && bytes[1] === 255) return "xml";
  return "unknown";
}
function collector(max2) {
  const chunks = [];
  let total = 0;
  return {
    add(chunk) {
      total += chunk.length;
      if (total > max2) throw new UnpackError("too_big");
      chunks.push(chunk);
    },
    bytes() {
      const out = new Uint8Array(total);
      let at = 0;
      for (const c of chunks) {
        out.set(c, at);
        at += c.length;
      }
      return out;
    }
  };
}
function gunzip(bytes, max2) {
  const out = collector(max2);
  try {
    const gz = new Gunzip((chunk) => out.add(chunk));
    gz.push(bytes, true);
  } catch (err2) {
    if (err2 instanceof UnpackError) throw err2;
    throw new UnpackError("corrupt");
  }
  return out.bytes();
}
function unzipFirstXml(bytes, max2) {
  const out = collector(max2);
  let found = false;
  try {
    const unzip = new Unzip();
    unzip.register(UnzipInflate);
    unzip.register(UnzipPassThrough);
    unzip.onfile = (file) => {
      if (found || !/\.xml$/i.test(file.name)) return;
      found = true;
      file.ondata = (err2, chunk) => {
        if (err2) throw err2;
        out.add(chunk);
      };
      file.start();
    };
    unzip.push(bytes, true);
  } catch (err2) {
    if (err2 instanceof UnpackError) throw err2;
    throw new UnpackError("corrupt");
  }
  if (!found) throw new UnpackError("unsupported");
  return out.bytes();
}
function declaredEncoding(bytes) {
  if (bytes[0] === 255 && bytes[1] === 254) return "utf-16le";
  if (bytes[0] === 254 && bytes[1] === 255) return "utf-16be";
  const head2 = new TextDecoder("latin1").decode(bytes.subarray(0, 200));
  const m = /^\s*<\?xml[^>]*\sencoding\s*=\s*["']([A-Za-z0-9._-]+)["']/.exec(head2);
  return m ? m[1] : "utf-8";
}
function decode(bytes) {
  const label = declaredEncoding(bytes);
  try {
    return new TextDecoder(label).decode(bytes);
  } catch {
    return new TextDecoder("utf-8").decode(bytes);
  }
}
function unpackReport(data, max2 = MAX_XML_BYTES) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  switch (sniff(bytes)) {
    case "gzip":
      return decode(gunzip(bytes, max2));
    case "zip":
      return decode(unzipFirstXml(bytes, max2));
    case "xml":
      if (bytes.length > max2) throw new UnpackError("too_big");
      return decode(bytes);
    default:
      throw new UnpackError("unsupported");
  }
}

// dmarc-reports/src/lib/parse.js
var MAX_ROWS = 2e3;
var MAX_COUNT = 1e9;
var ReportError = class extends Error {
  constructor(code) {
    super(code);
    this.name = "ReportError";
    this.code = code;
  }
};
var lower = (s) => String(s ?? "").toLowerCase();
function kids(el, name) {
  if (!el) return [];
  const want = lower(name);
  return Array.from(el.children ?? []).filter((c) => lower(c.localName ?? c.nodeName) === want);
}
var kid = (el, name) => kids(el, name)[0] ?? null;
var text = (el, name) => (kid(el, name)?.textContent ?? "").trim();
function count(value) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? Math.min(n, MAX_COUNT) : 0;
}
function seconds(value) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n * 1e3 : null;
}
function parseRecord(rec) {
  const row = kid(rec, "row");
  const evaluated = kid(row, "policy_evaluated");
  const ids = kid(rec, "identifiers");
  const auth = kid(rec, "auth_results");
  const record = {
    ip: text(row, "source_ip"),
    count: count(text(row, "count")),
    disposition: lower(text(evaluated, "disposition")) || "none",
    dkim: lower(text(evaluated, "dkim")),
    spf: lower(text(evaluated, "spf")),
    reasons: kids(evaluated, "reason").map((r) => ({ type: text(r, "type"), comment: text(r, "comment") })),
    headerFrom: text(ids, "header_from"),
    envelopeFrom: text(ids, "envelope_from"),
    envelopeTo: text(ids, "envelope_to"),
    dkimResults: kids(auth, "dkim").map((d) => ({
      domain: text(d, "domain"),
      selector: text(d, "selector"),
      result: lower(text(d, "result"))
    })),
    spfResults: kids(auth, "spf").map((s) => ({
      domain: text(s, "domain"),
      scope: text(s, "scope"),
      result: lower(text(s, "result"))
    }))
  };
  record.pass = record.dkim === "pass" || record.spf === "pass";
  return record;
}
function totalsOf(records) {
  const t = { messages: 0, passed: 0, failed: 0, none: 0, quarantine: 0, reject: 0, sources: 0 };
  const ips = /* @__PURE__ */ new Set();
  for (const r of records) {
    t.messages += r.count;
    if (r.pass) t.passed += r.count;
    else t.failed += r.count;
    if (r.disposition === "quarantine" || r.disposition === "reject") t[r.disposition] += r.count;
    else t.none += r.count;
    if (r.ip) ips.add(r.ip);
  }
  t.sources = ips.size;
  return t;
}
function parseReport(xml) {
  const source = String(xml ?? "");
  if (/<!DOCTYPE/i.test(source) || /<!ENTITY/i.test(source)) throw new ReportError("doctype");
  let doc;
  try {
    doc = new DOMParser().parseFromString(source, "application/xml");
  } catch {
    throw new ReportError("invalid");
  }
  if (!doc || doc.getElementsByTagName("parsererror").length > 0) throw new ReportError("invalid");
  const root = doc.documentElement;
  if (!root || lower(root.localName ?? root.nodeName) !== "feedback") throw new ReportError("not_dmarc");
  const meta = kid(root, "report_metadata");
  const policy = kid(root, "policy_published");
  if (!meta && !policy) throw new ReportError("not_dmarc");
  const range = kid(meta, "date_range");
  const records = kids(root, "record").map(parseRecord);
  records.sort((a, b) => b.count - a.count);
  return {
    metadata: {
      org: text(meta, "org_name"),
      email: text(meta, "email"),
      contact: text(meta, "extra_contact_info"),
      reportId: text(meta, "report_id"),
      begin: seconds(text(range, "begin")),
      end: seconds(text(range, "end")),
      errors: kids(meta, "error").map((e) => (e.textContent ?? "").trim()).filter(Boolean)
    },
    policy: {
      domain: text(policy, "domain"),
      adkim: lower(text(policy, "adkim")) || "r",
      aspf: lower(text(policy, "aspf")) || "r",
      p: lower(text(policy, "p")),
      sp: lower(text(policy, "sp")),
      np: lower(text(policy, "np")),
      pct: text(policy, "pct"),
      fo: text(policy, "fo"),
      testing: lower(text(policy, "testing"))
    },
    totals: totalsOf(records),
    records: records.slice(0, MAX_ROWS),
    truncated: Math.max(0, records.length - MAX_ROWS)
  };
}

// dmarc-reports/src/ui/details.js
var import_ui = require("@plugin-host/ui");

// dmarc-reports/src/lib/ip.js
function parseV4(text2) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(text2);
  if (!m) return null;
  const parts = m.slice(1).map((s) => s.length > 1 && s[0] === "0" ? NaN : Number(s));
  return parts.every((n) => n >= 0 && n <= 255) ? parts : null;
}
function canonicalV6(words) {
  let best = { at: -1, len: 0 };
  for (let i2 = 0; i2 < 8; ) {
    if (words[i2] !== 0) {
      i2++;
      continue;
    }
    let j = i2;
    while (j < 8 && words[j] === 0) j++;
    if (j - i2 > best.len) best = { at: i2, len: j - i2 };
    i2 = j;
  }
  const hex = (w) => w.toString(16);
  if (best.len < 2) return words.map(hex).join(":");
  const head2 = words.slice(0, best.at).map(hex).join(":");
  const tail = words.slice(best.at + best.len).map(hex).join(":");
  return `${head2}::${tail}`;
}
function parseV6(text2) {
  if (!/^[0-9a-fA-F:.]+$/.test(text2) || !text2.includes(":")) return null;
  let t = text2;
  if (t.includes(".")) {
    const cut = t.lastIndexOf(":") + 1;
    const v4 = parseV4(t.slice(cut));
    if (!v4) return null;
    t = `${t.slice(0, cut)}${(v4[0] << 8 | v4[1]).toString(16)}:${(v4[2] << 8 | v4[3]).toString(16)}`;
  }
  const halves = t.split("::");
  if (halves.length > 2) return null;
  const groups = (s) => s === "" ? [] : s.split(":");
  const head2 = groups(halves[0]);
  const tail = halves.length === 2 ? groups(halves[1]) : [];
  const all = [...head2, ...tail];
  if (!all.every((g) => /^[0-9a-fA-F]{1,4}$/.test(g))) return null;
  let words;
  if (halves.length === 1) {
    if (head2.length !== 8) return null;
    words = head2.map((g) => parseInt(g, 16));
  } else {
    if (head2.length + tail.length > 7) return null;
    words = [...head2.map((g) => parseInt(g, 16)), ...new Array(8 - all.length).fill(0), ...tail.map((g) => parseInt(g, 16))];
  }
  return words;
}
function parseIp(value) {
  const text2 = String(value ?? "").trim();
  if (text2.length === 0 || text2.length > 45) return null;
  const v4 = parseV4(text2);
  if (v4) return { version: 4, parts: v4, text: v4.join(".") };
  const v6 = parseV6(text2);
  if (v6) return { version: 6, words: v6, text: canonicalV6(v6) };
  return null;
}
var V4_SPECIAL = [
  ["0.0.0.0", 8],
  ["10.0.0.0", 8],
  ["100.64.0.0", 10],
  ["127.0.0.0", 8],
  ["169.254.0.0", 16],
  ["172.16.0.0", 12],
  ["192.0.0.0", 24],
  ["192.0.2.0", 24],
  ["192.88.99.0", 24],
  ["192.168.0.0", 16],
  ["198.18.0.0", 15],
  ["198.51.100.0", 24],
  ["203.0.113.0", 24],
  ["224.0.0.0", 4],
  ["240.0.0.0", 4]
].map(([base, bits2]) => ({ base: toInt(parseV4(base)), mask: bits2 === 0 ? 0 : 4294967295 << 32 - bits2 >>> 0 }));
function toInt([a, b, c, d]) {
  return ((a * 256 + b) * 256 + c) * 256 + d >>> 0;
}
var V6_SPECIAL = [["2001::", 23], ["2001:db8::", 32], ["3fff::", 20], ["2002::", 16]].map(([base, bits2]) => ({ words: parseV6(base), bits: bits2 }));
function v6Within(words, prefix) {
  let bits2 = prefix.bits;
  for (let i2 = 0; bits2 > 0; i2++, bits2 -= 16) {
    const mask = bits2 >= 16 ? 65535 : 65535 << 16 - bits2 & 65535;
    if ((words[i2] & mask) !== (prefix.words[i2] & mask)) return false;
  }
  return true;
}
function isPublic(ip) {
  const parsed = typeof ip === "string" ? parseIp(ip) : ip;
  if (!parsed) return false;
  if (parsed.version === 4) {
    const n = toInt(parsed.parts);
    return !V4_SPECIAL.some((r) => (n & r.mask) >>> 0 === (r.base & r.mask) >>> 0);
  }
  if ((parsed.words[0] & 57344) !== 8192) return false;
  return !V6_SPECIAL.some((p) => v6Within(parsed.words, p));
}
function ptrName(ip) {
  const parsed = typeof ip === "string" ? parseIp(ip) : ip;
  if (!parsed) throw new Error("not an IP address");
  if (parsed.version === 4) return `${[...parsed.parts].reverse().join(".")}.in-addr.arpa`;
  const nibbles = parsed.words.map((w) => w.toString(16).padStart(4, "0")).join("");
  return `${[...nibbles].reverse().join(".")}.ip6.arpa`;
}

// dmarc-reports/src/lib/dns.js
var RESOLVERS = {
  cloudflare: {
    label: "Cloudflare",
    origin: "https://cloudflare-dns.com",
    query: (name, type) => `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`,
    headers: { accept: "application/dns-json" }
  },
  google: {
    label: "Google Public DNS",
    origin: "https://dns.google",
    query: (name, type) => `https://dns.google/resolve?name=${encodeURIComponent(name)}&type=${type}`,
    headers: { accept: "application/json" }
  }
};
var TYPE2 = { A: 1, PTR: 12, AAAA: 28 };
var HOUR = 36e5;
var TTL_VERIFIED = 24 * HOUR;
var TTL_UNVERIFIED = 6 * HOUR;
var TTL_NONE = HOUR;
var TTL_ERROR = 6e4;
var CACHE_KEY = "rdns";
function normalizeHost(value) {
  const host2 = String(value ?? "").trim().replace(/\.$/, "").toLowerCase();
  if (host2.length === 0 || host2.length > 253) return null;
  const labels = host2.split(".");
  return labels.every((l) => /^[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?$/.test(l)) ? host2 : null;
}
function classifyError(error) {
  const message = String(error?.message ?? error ?? "");
  if (/lacks permission/i.test(message)) return "permission";
  if (/httpOrigins|redirected to/i.test(message)) return "origin";
  if (/^timeout$/i.test(message)) return "timeout";
  if (/^http \d+/.test(message)) return "http";
  if (/^dns status/.test(message)) return "dns";
  if (/failed to fetch|networkerror|load failed|network request failed/i.test(message)) return "network";
  if (/json|bad answer|unexpected token|unexpected end/i.test(message)) return "answer";
  return "other";
}
function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error("timeout")), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
function makeResolver(api, { now = () => Date.now(), concurrency = 4, timeoutMs = 8e3, maxCache = 300 } = {}) {
  const memory = /* @__PURE__ */ new Map();
  const inflight = /* @__PURE__ */ new Map();
  let persisted = null;
  let dirty = false;
  let flushTimer = null;
  let active = 0;
  const waiting = [];
  const provider = () => {
    const key = api.plugin?.settings?.rdns;
    return typeof key === "string" && Object.hasOwn(RESOLVERS, key) ? RESOLVERS[key] : null;
  };
  function gate(task) {
    return new Promise((resolve2, reject) => {
      const run = () => {
        active += 1;
        task().then(resolve2, reject).finally(() => {
          active -= 1;
          waiting.shift()?.();
        });
      };
      if (active < concurrency) run();
      else waiting.push(run);
    });
  }
  async function ask(p, name, type) {
    const res = await withTimeout(api.http.fetch(p.query(name, type), { method: "GET", headers: p.headers }), timeoutMs);
    if (!res?.ok) throw new Error(`http ${res?.status}`);
    const json = JSON.parse(res.bodyText);
    if (typeof json !== "object" || json === null) throw new Error("bad answer");
    return json;
  }
  const answers = (json, type) => Array.isArray(json.Answer) ? json.Answer.filter((a) => a && a.type === type && typeof a.data === "string").slice(0, 20).map((a) => a.data) : [];
  const none = (ip) => ({ ip, status: "none", host: null, verified: null, dnssec: false });
  async function resolve(parsed, p) {
    const ptr = await ask(p, ptrName(parsed), "PTR");
    if (ptr.Status === 3) return none(parsed.text);
    if (ptr.Status !== 0) throw new Error(`dns status ${ptr.Status}`);
    const hosts = [...new Set(answers(ptr, TYPE2.PTR).map(normalizeHost).filter(Boolean))].slice(0, 3);
    if (hosts.length === 0) return none(parsed.text);
    const forward = parsed.version === 4 ? "A" : "AAAA";
    let dnssec = ptr.AD === true;
    let confirmed = null;
    for (const host2 of hosts) {
      const json = await ask(p, host2, forward);
      dnssec = dnssec && json.AD === true;
      const addresses = answers(json, TYPE2[forward]).map(parseIp).filter(Boolean).map((a) => a.text);
      if (addresses.includes(parsed.text)) {
        confirmed = host2;
        break;
      }
    }
    return { ip: parsed.text, status: "ok", host: confirmed ?? hosts[0], verified: confirmed !== null, dnssec: confirmed !== null && dnssec };
  }
  const ttlOf = (r) => r.status === "none" ? TTL_NONE : r.verified ? TTL_VERIFIED : TTL_UNVERIFIED;
  async function stored() {
    persisted ?? (persisted = (async () => {
      let data = null;
      try {
        data = await api.storage.get(CACHE_KEY);
      } catch {
      }
      const entries = data && typeof data === "object" && data.v === 1 && data.e && typeof data.e === "object" ? data.e : {};
      for (const [ip, [host2, code, dnssec, expires]] of Object.entries(entries)) {
        if (!(expires > now())) continue;
        memory.set(ip, { ip, status: code === -1 ? "none" : "ok", host: host2 || null, verified: code === -1 ? null : code === 1, dnssec: dnssec === 1, expires });
      }
    })());
    return persisted;
  }
  function scheduleFlush() {
    dirty = true;
    if (flushTimer) return;
    flushTimer = setTimeout(() => {
      flushTimer = null;
      void flush();
    }, 300);
  }
  async function flush() {
    if (!dirty) return;
    dirty = false;
    const live = [...memory.values()].filter((r) => r.expires > now() && (r.status === "ok" || r.status === "none"));
    live.sort((a, b) => b.expires - a.expires);
    const e = {};
    for (const r of live.slice(0, maxCache)) e[r.ip] = [r.host ?? "", r.status === "none" ? -1 : r.verified ? 1 : 0, r.dnssec ? 1 : 0, r.expires];
    try {
      await api.storage.set(CACHE_KEY, { v: 1, e });
    } catch {
    }
  }
  async function lookup(ip) {
    const p = provider();
    if (!p) return { ip, status: "off", host: null, verified: null, dnssec: false };
    const parsed = parseIp(ip);
    if (!parsed || !isPublic(parsed)) return { ip, status: "skipped", host: null, verified: null, dnssec: false };
    await stored();
    const hit = memory.get(parsed.text);
    if (hit && hit.expires > now()) return hit;
    if (inflight.has(parsed.text)) return inflight.get(parsed.text);
    const job = gate(() => resolve(parsed, p)).then(
      (result) => {
        const out = { ...result, expires: now() + ttlOf(result) };
        memory.set(parsed.text, out);
        scheduleFlush();
        return out;
      },
      (error) => {
        api.log.warn("dmarc-reports: reverse lookup failed", error?.message);
        const out = {
          ip: parsed.text,
          status: "error",
          reason: classifyError(error),
          detail: String(error?.message ?? error ?? "").slice(0, 160),
          host: null,
          verified: null,
          dnssec: false,
          expires: now() + TTL_ERROR
        };
        memory.set(parsed.text, out);
        return out;
      }
    ).finally(() => inflight.delete(parsed.text));
    inflight.set(parsed.text, job);
    return job;
  }
  return { lookup, flush, enabled: () => provider() !== null, label: () => provider()?.label ?? "" };
}

// dmarc-reports/src/lib/view.js
function formatInstant(ms, locale) {
  if (!Number.isFinite(ms)) return "";
  try {
    return new Intl.DateTimeFormat(locale || void 0, {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: "UTC"
    }).format(new Date(ms));
  } catch {
    return new Date(ms).toISOString().slice(0, 16).replace("T", " ");
  }
}
function periodText(metadata, locale) {
  const from = formatInstant(metadata?.begin, locale);
  const to = formatInstant(metadata?.end, locale);
  return from && to ? `${from} – ${to}` : from || to;
}
function resultTone(result) {
  switch (result) {
    case "pass":
      return "success";
    case "fail":
    case "permerror":
      return "danger";
    case "softfail":
    case "temperror":
    case "policy":
      return "warning";
    default:
      return "neutral";
  }
}
function dispositionTone(disposition) {
  if (disposition === "reject") return "danger";
  if (disposition === "quarantine") return "warning";
  return "neutral";
}
function barLook(report, verdict) {
  if (verdict === "suspicious") return { tone: "warning", icon: "shield-exclamation" };
  if (report.totals.failed > 0) return { tone: "warning", icon: "shield-exclamation" };
  return { tone: "success", icon: "shield-check" };
}
function errorKey(err2) {
  switch (err2?.code) {
    case "unsupported":
      return "error.unsupported";
    case "too_big":
      return "error.tooBig";
    case "corrupt":
      return "error.corrupt";
    case "doctype":
      return "error.doctype";
    case "invalid":
      return "error.invalid";
    case "not_dmarc":
      return "error.notDmarc";
    default:
      return "error.read";
  }
}

// dmarc-reports/src/ui/details.js
var FIRST_ROWS = 100;
var cell = { padding: "4px 8px", textAlign: "left", verticalAlign: "top", borderBottom: "1px solid var(--color-border)" };
var head = { ...cell, fontWeight: 600, color: "var(--color-muted-foreground)", whiteSpace: "nowrap", position: "sticky", top: 0, background: "var(--color-background)" };
var COLUMNS = ["ip", "host", "count", "disposition", "dkim", "spf", "from", "auth"];
function makeReportDetails(React2, api, resolver = makeResolver(api)) {
  const { createElement: h, useEffect, useMemo, useState } = React2;
  const t = (key, vars) => api.i18n.t(key, vars);
  const badge = (result) => result ? h(import_ui.Badge, { tone: resultTone(result) }, result) : "–";
  function HostCell({ result }) {
    if (!result) return h(import_ui.Spinner, { size: "sm" });
    switch (result.status) {
      case "ok":
        return h(
          "span",
          null,
          h("span", { style: { fontFamily: "monospace", wordBreak: "break-all" } }, result.host),
          " ",
          result.verified ? h(import_ui.Badge, { tone: "success" }, t("details.host.verified")) : h("span", { title: t("details.host.mismatchHelp") }, h(import_ui.Badge, { tone: "warning" }, t("details.host.mismatch"))),
          result.dnssec ? h(import_ui.Badge, { tone: "info" }, "DNSSEC") : null
        );
      case "none":
        return h(import_ui.Text, { tone: "muted" }, t("details.host.none"));
      case "error":
        return h("span", { title: result.detail || result.reason }, h(import_ui.Text, { tone: "muted" }, t("details.host.error")));
      default:
        return "–";
    }
  }
  function authCell(record) {
    const lines = [
      ...record.dkimResults.map((d, i2) => h("div", { key: `d${i2}` }, `DKIM ${d.domain}${d.selector ? ` (${d.selector})` : ""} `, badge(d.result))),
      ...record.spfResults.map((s, i2) => h("div", { key: `s${i2}` }, `SPF ${s.domain} `, badge(s.result)))
    ];
    return lines.length ? lines : "–";
  }
  const row = (label, value, mono) => value ? h(import_ui.DetailRow, { label, mono }, value) : null;
  return function ReportDetails({ report, verdict }) {
    const { metadata, policy, totals } = report;
    const locale = api.i18n.getLocale?.();
    const [showAll, setShowAll] = useState(false);
    const [asked, setAsked] = useState(false);
    const [hosts, setHosts] = useState({});
    const enabled = resolver.enabled();
    const lookupNow = enabled && (verdict === "trusted" || asked);
    const rows = useMemo(() => showAll ? report.records : report.records.slice(0, FIRST_ROWS), [report, showAll]);
    useEffect(() => {
      if (!lookupNow) return void 0;
      let live = true;
      for (const ip of new Set(rows.map((r) => r.ip))) {
        resolver.lookup(ip).then((result) => {
          if (live) setHosts((known) => known[ip] ? known : { ...known, [ip]: result });
        });
      }
      return () => {
        live = false;
      };
    }, [lookupNow, rows]);
    const problem = (() => {
      const counts = /* @__PURE__ */ new Map();
      for (const r of Object.values(hosts)) {
        if (r.status === "error") counts.set(r.reason, { n: (counts.get(r.reason)?.n ?? 0) + 1, detail: r.detail });
      }
      const [reason, info] = [...counts.entries()].sort((a, b) => b[1].n - a[1].n)[0] ?? [];
      return reason ? { reason, detail: info.detail } : null;
    })();
    return h(
      import_ui.Panel,
      null,
      h(
        import_ui.Stack,
        { gap: 4 },
        h(
          "div",
          null,
          h(import_ui.DetailHeading, null, t("details.report")),
          h(
            import_ui.DetailList,
            null,
            row(t("details.reporter"), [metadata.org, metadata.email].filter(Boolean).join(" · ")),
            row(t("details.contact"), metadata.contact),
            row(t("details.reportId"), metadata.reportId, true),
            row(t("details.period"), periodText(metadata, locale)),
            row(t("details.totals"), t("bar.counts", { messages: totals.messages, passed: totals.passed, failed: totals.failed })),
            row(t("details.dispositions"), t("details.dispositionsValue", { none: totals.none, quarantine: totals.quarantine, reject: totals.reject })),
            row(t("details.errors"), metadata.errors.join("; "))
          )
        ),
        h(
          "div",
          null,
          h(import_ui.DetailHeading, null, t("details.policy")),
          h(
            import_ui.DetailList,
            null,
            row(t("details.domain"), policy.domain),
            row("p / sp / np", [policy.p, policy.sp, policy.np].filter(Boolean).join(" / ")),
            row("pct", policy.pct),
            row("adkim / aspf", `${policy.adkim} / ${policy.aspf}`),
            row("fo", policy.fo),
            row("testing", policy.testing)
          )
        ),
        h(
          "div",
          null,
          h(import_ui.DetailHeading, null, t("details.sources")),
          h(
            import_ui.Stack,
            { gap: 2 },
            !enabled ? h(import_ui.Text, { tone: "muted" }, t("details.rdnsOff")) : null,
            enabled && !lookupNow ? h(
              import_ui.Row,
              { gap: 2 },
              h(import_ui.Button, { size: "sm", variant: "secondary", onClick: () => setAsked(true) }, t("details.lookup")),
              h(import_ui.Text, { tone: "muted" }, t("details.rdnsHold", { resolver: resolver.label() }))
            ) : null,
            lookupNow ? h(import_ui.Text, { tone: "muted" }, t("details.rdnsVia", { resolver: resolver.label() })) : null,
            problem ? h("div", { role: "alert" }, h(import_ui.Text, { tone: "danger" }, t(`details.problem.${problem.reason}`, { resolver: resolver.label(), detail: problem.detail || "" }))) : null,
            h(
              "div",
              { style: { overflow: "auto", maxHeight: 480 } },
              h(
                "table",
                { style: { borderCollapse: "collapse", width: "100%", fontSize: "0.9em" } },
                h("thead", null, h("tr", null, COLUMNS.map((key) => h("th", { key, style: head, scope: "col" }, t(`details.col.${key}`))))),
                h("tbody", null, rows.map((r, i2) => h(
                  "tr",
                  { key: i2 },
                  h("td", { style: { ...cell, fontFamily: "monospace" } }, r.ip || "–"),
                  h("td", { style: cell }, lookupNow ? h(HostCell, { result: hosts[r.ip] }) : "–"),
                  h("td", { style: cell }, r.count),
                  h("td", { style: cell }, h(import_ui.Badge, { tone: dispositionTone(r.disposition) }, r.disposition)),
                  h("td", { style: cell }, badge(r.dkim)),
                  h("td", { style: cell }, badge(r.spf)),
                  h("td", { style: cell }, r.headerFrom || "–"),
                  h("td", { style: cell }, authCell(r))
                )))
              )
            ),
            report.records.length > rows.length ? h(import_ui.Row, { gap: 2 }, h(import_ui.Button, { size: "sm", variant: "ghost", onClick: () => setShowAll(true) }, t("details.showAll", { total: report.records.length }))) : null,
            report.truncated > 0 ? h(import_ui.Text, { tone: "muted" }, t("details.truncated", { shown: report.records.length, total: report.records.length + report.truncated })) : null
          )
        )
      )
    );
  };
}

// dmarc-reports/src/lib/sender.js
var domainOf = (address) => String(address ?? "").split("@").pop().trim().toLowerCase();
function related(a, b) {
  if (!a || !b) return false;
  return a === b || a.endsWith(`.${b}`) || b.endsWith(`.${a}`);
}
function senderCheck(email, report) {
  const auth = email?.auth ?? null;
  let authenticated = null;
  if (auth?.dmarc?.result === "pass") authenticated = true;
  else if ([auth?.dmarc?.result, auth?.dkim?.result, auth?.spf?.result].includes("fail")) authenticated = false;
  const from = domainOf(email?.from?.[0]?.email);
  const reporter = domainOf(report?.metadata?.email);
  const orgMatches = from && reporter ? related(from, reporter) : null;
  let verdict = "unknown";
  if (authenticated === false || orgMatches === false) verdict = "suspicious";
  else if (authenticated === true && orgMatches === true) verdict = "trusted";
  return { authenticated, orgMatches, verdict };
}

// dmarc-reports/src/ui/banner.js
function makeReportBanner(React2, api) {
  const { createElement: h, useEffect, useState } = React2;
  const t = (key, vars) => api.i18n.t(key, vars);
  const Details = makeReportDetails(React2, api);
  async function load(emailId, attachment) {
    const file = await api.email.getAttachment(emailId, attachment.blobId);
    return parseReport(unpackReport(file.data));
  }
  function ReportBar({ email, attachment }) {
    const [state, setState] = useState({ status: "loading" });
    const [expanded, setExpanded] = useState(false);
    useEffect(() => {
      let live = true;
      setState({ status: "loading" });
      load(email.id, attachment).then(
        (report2) => {
          if (live) setState({ status: "ready", report: report2 });
        },
        (error) => {
          api.log.warn("dmarc-reports: could not read a report", error?.code ?? error?.message);
          if (live) setState({ status: "error", error });
        }
      );
      return () => {
        live = false;
      };
    }, [email.id, attachment.blobId]);
    if (state.status === "loading") return h(import_ui2.InfoBar, { tone: "neutral", icon: "shield", eyebrow: t("bar.eyebrow"), compact: true }, h(import_ui2.Loading, { label: t("bar.loading") }));
    if (state.status === "error") {
      return h(
        import_ui2.InfoBar,
        { tone: "neutral", icon: "shield", eyebrow: t("bar.eyebrow"), title: attachment.name },
        h("div", { role: "status" }, h(import_ui2.Text, { tone: "muted" }, t(errorKey(state.error), { limit: Math.round(MAX_XML_BYTES / 1048576) })))
      );
    }
    const { report } = state;
    const check = senderCheck(email, report);
    const { tone, icon } = barLook(report, check.verdict);
    const { metadata, policy, totals } = report;
    const org = metadata.org || metadata.email || "?";
    const period = periodText(metadata, api.i18n.getLocale?.());
    return h(
      "div",
      { "data-dmarc-report": report.policy.domain },
      h(
        import_ui2.InfoBar,
        { tone, icon, eyebrow: t("bar.eyebrow"), title: t("bar.title", { domain: policy.domain || "?", org }) },
        period ? h(import_ui2.Text, { tone: "muted" }, period) : null,
        h(import_ui2.Text, { tone: "muted" }, t("bar.counts", { messages: totals.messages, passed: totals.passed, failed: totals.failed })),
        h(import_ui2.Text, { tone: "muted" }, t("bar.policy", { p: policy.p || "–", sp: policy.sp || policy.p || "–", pct: policy.pct || "100" })),
        check.authenticated === false ? h("div", { role: "alert" }, h(import_ui2.Text, { tone: "danger" }, t("bar.warnAuth"))) : null,
        check.orgMatches === false ? h("div", { role: "alert" }, h(import_ui2.Text, { tone: "danger" }, t("bar.warnOrg", { org }))) : null,
        check.verdict === "unknown" ? h(import_ui2.Text, { tone: "muted" }, t("bar.unverified")) : null,
        h(import_ui2.Row, { gap: 2 }, h(import_ui2.BarButton, { icon: expanded ? "chevron-up" : "chevron-down", active: expanded, onClick: () => setExpanded((v) => !v) }, t("bar.details")))
      ),
      expanded ? h(Details, { report, verdict: check.verdict }) : null
    );
  }
  return function ReportBanner(props) {
    const email = props?.email ?? null;
    if (!email) return null;
    const attachments = reportAttachments(email);
    if (attachments.length === 0) return null;
    return h("div", null, attachments.map((attachment) => h(ReportBar, { key: attachment.blobId, email, attachment })));
  };
}

// dmarc-reports/src/index.js
var index_default = {
  slots: {
    "email-banner": { component: makeReportBanner(React, import_plugin_host.default), shouldShow }
  }
};
